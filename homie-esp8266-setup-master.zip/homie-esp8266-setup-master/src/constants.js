export const API_URL = 'http://192.168.123.1'
export const HEARTBEAT_ATTEMPT_INTERVAL = 3 * 1000
